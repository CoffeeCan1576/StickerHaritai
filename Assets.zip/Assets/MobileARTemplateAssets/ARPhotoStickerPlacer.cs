
using System.Collections.Generic; // List<T>など、複数のデータをまとめて管理する機能を使う
using System.IO;                  // ファイルの読み込みなど、ファイル操作の機能を使う
using UnityEngine;                // GameObject、Transform、Vector3などUnityの基本機能を使う
using UnityEngine.UI;             // Buttonなど、UnityのUI機能を使う
using UnityEngine.EventSystems;    // タップがUI上で行われたか調べる機能を使う
using UnityEngine.XR.ARFoundation; // ARSessionやARRaycastManagerなどAR機能を使う
using UnityEngine.XR.ARSubsystems; // PlaneWithinPolygonなどARの共通機能を使う

// このクラスが、写真の選択とAR空間への配置を担当する
// MonoBehaviourを継承することで、UnityのGameObjectに取り付けられる
public class ARPhotoStickerPlacer : MonoBehaviour
{
    [Header("AR Components")] // Inspectorに表示する項目の見出し
    public ARRaycastManager raycastManager;
    // AR空間に向けたタップ位置から、検出済みの平面を探すための部品
    // InspectorでAR Raycast Managerを設定する

    [Header("Optional UI")] // UI関連の設定項目の見出し
    public Button choosePhotoButton;
    // 写真選択ボタン
    // Inspectorで対象のButtonを設定する
    // 未設定の場合、このボタンからの選択処理は登録されない

    [Header("Sticker Settings")] // ステッカー設定の見出し
    [Min(0.01f)] // Inspectorで設定できる値の最小値を0.01にする
    public float stickerHeight = 0.2f;
    // ステッカーの高さ。AR空間内の単位で指定する
    // 初期値は0.2。幅は写真の縦横比から自動計算する

    private Texture2D selectedTexture;
    // 選択した写真の画像データを保存する変数
    // privateなので、このクラスの外から直接アクセスできない

    // AR平面へのタップ判定結果を保存するリスト
    // static readonlyにより、リスト自体の参照を変更せずに使う
    private static readonly List<ARRaycastHit> hits =
        new List<ARRaycastHit>();

    void Start()
    {
        // 写真選択ボタンがInspectorで設定されている場合だけ処理する
        if (choosePhotoButton != null)

            // ボタンが押されたらPickPhoto()を呼び出す
            choosePhotoButton.onClick.AddListener(PickPhoto);
    }

    public void PickPhoto()
    {
        // iPhoneのギャラリーを開き、選んだ画像のパスを受け取る
        // 処理が終わると、コールバック関数が実行される
        NativeGallery.GetImageFromGallery(
            (path) =>
            {
                // 写真が選ばれなかった場合など、パスが空なら終了する
                if (string.IsNullOrEmpty(path))
                    return;

                // 選択された写真ファイルをバイト配列として読み込む
                byte[] bytes = File.ReadAllBytes(path);

                // 画像を読み込むためのTexture2Dを作る
                // 最初は仮に2×2ピクセルで作成する
                Texture2D texture = new Texture2D(
                    2, 2, TextureFormat.RGBA32, false
                );

                // ファイルのデータをTexture2Dに読み込む
                // 読み込みに失敗したらtrueではなくfalseが返る
                if (!texture.LoadImage(bytes))
                {
                    // 読み込みに失敗したTexture2Dを破棄する
                    Destroy(texture);

                    // UnityのConsoleにエラーメッセージを出す
                    Debug.LogError("画像を読み込めませんでした");

                    // これ以上の処理を行わず終了する
                    return;
                }

                // 前に選択した画像があれば破棄する
                if (selectedTexture != null)
                    Destroy(selectedTexture);

                // 今回読み込んだ画像を、選択中の写真として保存する
                selectedTexture = texture;

                // Consoleに写真の選択が完了したことを表示する
                Debug.Log("写真を選択しました。配置したい場所をタップしてください。");
            },

            // ギャラリーを開く画面のタイトル
            "貼り付ける写真を選択",

            // 選択対象を画像ファイルに限定するための指定
            "image/*"
        );
    }

    void Update()
    {
        // 写真がまだ選択されていない場合、メッセージを出す
        if (selectedTexture == null)
            Debug.Log("写真がまだ選択されていません");

        // ARRaycastManagerが設定されていない場合、エラーを出す
        if (raycastManager == null)
            Debug.LogError("Raycast Manager が未設定です");

        // タッチが1つもなければ、このフレームの処理を終了する
        if (Input.touchCount == 0)
            return;

        // 最初のタッチ情報を取得する
        Touch touch = Input.GetTouch(0);

        // 指を画面に触れた瞬間以外は、配置処理を行わない
        if (touch.phase != TouchPhase.Began)
            return;

        // EventSystemが存在し、タップ位置がUI上なら処理を終了する
        // これにより、ボタンを押したときに写真が配置されるのを防ぐ
        if (EventSystem.current != null &&
            EventSystem.current.IsPointerOverGameObject(touch.fingerId))
            return;

        // タップした画面座標から、検出されたAR平面を探す
        // PlaneWithinPolygonは、検出した平面のポリゴン内部を対象とする
        if (raycastManager.Raycast(
            touch.position,
            hits,
            TrackableType.PlaneWithinPolygon))
        {
            // 見つかった最初の平面との交点の位置・向きを取得する
            Pose pose = hits[0].pose;

            // 平面に少しだけ浮かせて配置する
            // 0.005はAR空間の単位で5mm相当
            pose.position += pose.up * 0.005f;

            // 平面の法線方向を取得する
            // 平面から垂直に伸びる方向
            Vector3 normal = pose.up;

            // カメラの前方向を平面上に投影し、向きを決めるために使う
            Vector3 projectedForward =
                Vector3.ProjectOnPlane(
                    Camera.main.transform.forward, normal
                ).normalized;

            // 投影した方向がほぼゼロなら、カメラの上方向を使って再計算する
            if (projectedForward.sqrMagnitude < 0.001f)
                projectedForward =
                    Vector3.ProjectOnPlane(
                        Camera.main.transform.up, normal
                    ).normalized;

            // 平面の法線と投影した方向から回転を計算する
            Quaternion rotation =
                Quaternion.LookRotation(normal, projectedForward);

            // 計算した位置と回転で写真ステッカーを作る
            CreateSticker(pose.position, rotation);
        }
    }

    void CreateSticker(Vector3 position, Quaternion rotation)
    {
        // 空のGameObjectを作り、名前を付ける
        GameObject sticker = new GameObject("AR Photo Sticker");

        // ステッカーの位置と向きを設定する
        sticker.transform.SetPositionAndRotation(position, rotation);

        // 写真の横幅÷高さで、写真の縦横比を計算する
        float aspect =
            (float)selectedTexture.width / selectedTexture.height;

        // 写真の色をそのまま表示するためのシェーダーを探す
        Shader shader = Shader.Find("Unlit/Texture");

        // 見つからなければ、代わりにSprites/Defaultを探す
        if (shader == null)
            shader = Shader.Find("Sprites/Default");

        // 写真を表示するためのマテリアルを作る
        Material material = new Material(shader);

        // 選択した写真をマテリアルのテクスチャとして設定する
        material.mainTexture = selectedTexture;

        // 表面用と裏面用の2枚を作る
        for (int i = 0; i < 2; i++)
        {
            // 四角形の3Dオブジェクトを作る
            GameObject side = GameObject.CreatePrimitive(
                PrimitiveType.Quad
            );

            // iが0なら表面、1なら裏面という名前を付ける
            side.name = i == 0 ? "Front" : "Back";

            // ステッカーを親として登録する
            // 第2引数falseにより、ローカル座標で配置する
            side.transform.SetParent(sticker.transform, false);

            // 表裏の面を少しだけずらす
            // 2枚が同じ位置で重なるのを避ける
            side.transform.localPosition =
                new Vector3(0, 0, i == 0 ? 0.0005f : -0.0005f);

            // 裏面はY軸を180度回転させ、反対側から見えるようにする
            side.transform.localRotation =
                Quaternion.Euler(0, i == 0 ? 0 : 180, 0);

            // 写真の縦横比を保ち、高さをstickerHeightに設定する
            side.transform.localScale =
                new Vector3(stickerHeight * aspect, stickerHeight, 1);

            // 四角形に付いているRendererを取得する
            Renderer renderer = side.GetComponent<Renderer>();

            // 写真用のマテリアルを割り当てる
            renderer.sharedMaterial = material;

            // 四角形に付いているColliderを取得する
            Collider collider = side.GetComponent<Collider>();

            // Colliderがあれば削除する
            // 写真をタップしたときの不要な物理判定を避ける
            if (collider != null)
                Destroy(collider);
        }

        // ステッカーの配置完了をConsoleに表示する
        Debug.Log("写真ステッカーを配置しました");
    }

    void OnDestroy()
    {
        // ボタンが設定されている場合、クリック時の登録を解除する
        if (choosePhotoButton != null)
            choosePhotoButton.onClick.RemoveListener(PickPhoto);

        // 選択中の写真データが残っていれば破棄する
        if (selectedTexture != null)
            Destroy(selectedTexture);
    }
}
