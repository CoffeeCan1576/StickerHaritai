

using UnityEngine;

public class ARScreenSwitcher : MonoBehaviour
{
    // Inspectorから、切り替え対象の2つのオブジェクトを指定できるようにしています    
    public GameObject greetingPrompt;
    public GameObject selectPhotoButton;

    public void ShowPhotoScreen()
    {
        if (greetingPrompt != null)
           // Welcome画面（greetingPrompt）を非表示にします。
            greetingPrompt.SetActive(false);

        if (selectPhotoButton != null)
            // 写真選択ボタン（selectPhotoButton）を表示します。
            selectPhotoButton.SetActive(true);
    }
}
